import * as main from './main';

//load canvas
main.init();