export enum DEFAULTS {
    gain = .5,
    numSamples = 256
}

