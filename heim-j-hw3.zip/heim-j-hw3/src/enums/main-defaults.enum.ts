export enum DEFAULTS {
    sound1 = "media/music/Nocturne.mp3"
}
